# Release Notes 🥳

Check out the latest features and improvements. [See Releases →](https://github.com/ivodolenc/aspekta/releases)
